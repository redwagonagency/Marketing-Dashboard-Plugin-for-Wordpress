<?php
/**
 * Plugin Name: Marketing Metrics Dashboard
 * Plugin URI: https://redwagon.agency
 * Description: A lightweight plugin to display Google Data Studio reports in the WordPress admin dashboard.
 * Version: 1.1
 * Author: Red Wagon Agency
 * Author URI: https://redwagon.agency
 * License: GPLv2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: marketing-metrics-dashboard
 * Domain Path: /languages
 */

// Register a custom admin menu with submenus
add_action('admin_menu', function() {
    // Add a new top-level menu
    add_menu_page(
        'Marketing Dashboard',
        'Marketing Dashboard',
        'manage_options',
        'marketing-dashboard',
        'marketing_metrics_dashboard_page',
        'dashicons-chart-area',
        3
    );

    // Add the "My Marketing Dashboard" submenu
    add_submenu_page(
        'marketing-dashboard',
        'My Marketing Dashboard',
        'My Marketing Dashboard',
        'manage_options',
        'marketing-dashboard',
        'marketing_metrics_dashboard_page'
    );

    // Add the "Settings" submenu
    add_submenu_page(
        'marketing-dashboard',
        'Settings',
        'Settings',
        'manage_options',
        'marketing-dashboard-settings',
        'marketing_metrics_settings_page'
    );
});

// Render the "My Marketing Dashboard" page
function marketing_metrics_dashboard_page() {
    $data_studio_url = get_option('data_studio_report_url', '');
    ?>
    <div class="wrap">
        <h1>My Marketing Dashboard</h1>
        <?php if ($data_studio_url): ?>
            <iframe src="<?php echo esc_url($data_studio_url); ?>" width="100%" height="1200" frameborder="0" allowfullscreen></iframe>
        <?php else: ?>
            <p>Please set up your Google Data Studio Report URL in the <a href="admin.php?page=marketing-dashboard-settings">Settings</a>.</p>
        <?php endif; ?>
    </div>
    <?php
}

// Render the "Settings" page
function marketing_metrics_settings_page() {
    if (isset($_POST['data_studio_url'])) {
        $saved = update_option('data_studio_report_url', esc_url_raw($_POST['data_studio_url']));
        if ($saved) {
            echo '<div class="updated"><p>Settings saved successfully.</p></div>';
        } else {
            echo '<div class="error"><p>Failed to save settings. Please try again.</p></div>';
        }
    }

    $data_studio_url = get_option('data_studio_report_url', '');
    ?>
    <div class="wrap">
        <h1>Settings</h1>
        <form method="post">
            <label for="data_studio_url">Google Data Studio Report URL:</label><br>
            <input type="text" name="data_studio_url" id="data_studio_url" value="<?php echo esc_attr($data_studio_url); ?>" style="width: 400px;"><br><br>
            <input type="submit" class="button button-primary" value="Save Settings">
        </form>
    </div>
    <?php
}
?>
