<?php
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Plugin Name: Marketing Metrics Dashboard
 * Plugin URI: https://www.redwagon.agency/marketing-dashboard-wordpress-plugin/
 * Description: A lightweight plugin to display Google Data Studio reports in the WordPress admin dashboard.
 * Version: 1.1
 * Author: Red Wagon Agency
 * Author URI: https://www.redwagon.agency/developer-author/
 * License: GPLv2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: marketing-metrics-dashboard
 * Stable tag: 1.1
 * Tested up to: 6.8
 */

// Register a custom admin menu with submenus
add_action('admin_menu', function () {
    // Add a new top-level menu
    add_menu_page(
        'Marketing Dashboard',
        'Marketing Dashboard',
        'manage_options',
        'marketing-dashboard',
        'rw_mkt_metrics_dashboard_page',
        'dashicons-chart-area',
        3
    );

    // Add the "My Marketing Dashboard" submenu
    add_submenu_page(
        'marketing-dashboard',
        'My Marketing Dashboard',
        'My Marketing Dashboard',
        'manage_options',
        'marketing-dashboard',
        'rw_mkt_metrics_dashboard_page'
    );

    // Add the "Settings" submenu
    add_submenu_page(
        'marketing-dashboard',
        'Settings',
        'Settings',
        'manage_options',
        'marketing-dashboard-settings',
        'rw_mkt_metrics_settings_page'
    );
});

// Render the "My Marketing Dashboard" page
function rw_mkt_metrics_dashboard_page()
{
    $data_studio_url = get_option('rw_data_studio_report_url', '');

    ?>
    <div class="wrap">
        <h1>My Marketing Dashboard</h1>
        <?php if ($data_studio_url): ?>
            <iframe src="<?php echo esc_url($data_studio_url); ?>" width="100%" height="1200" frameborder="0"
                    allowfullscreen></iframe>
        <?php else: ?>
            <p>Please set up your Google Data Studio Report URL in the <a
                        href="admin.php?page=marketing-dashboard-settings">Settings</a>.</p>
        <?php endif; ?>
    </div>
    <?php
}

// Render the "Settings" page
function rw_mkt_metrics_settings_page()
{
    // Verify the request method and validate inputs
    if (isset($_SERVER['REQUEST_METHOD']) && $_SERVER['REQUEST_METHOD'] === 'POST') {
        if (isset($_POST['marketing_metrics_nonce']) && wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['marketing_metrics_nonce'])), 'marketing_metrics_save_settings')) {
            $data_studio_url = isset($_POST['data_studio_url']) ? sanitize_text_field(wp_unslash($_POST['data_studio_url'])) : '';
            $saved = update_option('rw_data_studio_report_url', esc_url_raw($data_studio_url));
            if ($saved) {
                echo '<div class="updated"><p>Settings saved successfully.</p></div>';
            } else {
                echo '<div class="error"><p>Failed to save settings. Please try again.</p></div>';
            }
        } else {
            wp_die('Nonce verification failed. Please try again.');
        }
    }

    $data_studio_url = get_option('rw_data_studio_report_url', ''); // Fixed the option name here
    ?>
    <div class="wrap">
        <h1>Settings</h1>
        <form method="post">
            <?php wp_nonce_field('marketing_metrics_save_settings', 'marketing_metrics_nonce'); ?>
            <label for="data_studio_url">Google Data Studio Report URL:</label><br>
            <input type="text" name="data_studio_url" id="data_studio_url"
                   value="<?php echo esc_attr($data_studio_url); ?>" style="width: 400px;"><br><br>
            <input type="submit" class="button button-primary" value="Save Settings">
        </form>
    </div>
    <?php
}
?>
