=== Marketing Metrics Dashboard ===
Contributors: redwagonagency
Tags: data studio, analytics, dashboard, reports, marketing
Requires at least: 5.0
Tested up to: 6.8
Requires PHP: 7.4
Stable tag: 1.1
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Display interactive Google Data Studio reports directly within your WordPress admin dashboard with ease and security.

== Description ==

The **Marketing Metrics Dashboard** plugin is a lightweight and efficient solution for embedding and viewing Google Data Studio reports directly in your WordPress admin panel. This plugin is perfect for marketers, business owners, and agencies looking for an all-in-one solution to monitor and share data analytics without leaving the WordPress environment.

### Key Features:
- **Embed Google Data Studio Reports**: Display reports in your WordPress admin area using a secure iframe.
- **Customizable Settings**: Easily set and update the report URL through a user-friendly settings page.
- **Secure Input Handling**: Built with WordPress security standards, including nonce verification and input sanitization.
- **No Coding Required**: Set up and configure the plugin with minimal effort.

With **Marketing Metrics Dashboard**, you can manage your Google Data Studio reports seamlessly while maintaining full control of your data.

== Installation ==

1. Download the plugin ZIP file.
2. Upload the plugin folder to `/wp-content/plugins/` or install it directly through the WordPress plugin repository.
3. Activate the plugin through the 'Plugins' menu in WordPress.
4. Access the plugin via the "Marketing Dashboard" menu in the WordPress admin area.
5. Go to "Settings" under the "Marketing Dashboard" menu to configure your Google Data Studio Report URL.

== Frequently Asked Questions ==

**Q: Do I need a Google account to use this plugin?**  
A: Yes, you need a Google account to create and manage Google Data Studio reports.

**Q: Can I use this plugin with multiple reports?**  
A: Currently, the plugin supports embedding a single report. You can update the report URL in the settings page as needed.

**Q: Is my data secure with this plugin?**  
A: Absolutely. The plugin uses WordPress security best practices, including nonce verification and input sanitization.

**Q: Does this plugin work on all WordPress installations?**  
A: This plugin works on WordPress 5.0 and later with PHP 7.4 or higher.

**Q: Can I embed reports on the front end?**  
A: This version of the plugin is designed specifically for admin dashboard use. Front-end embedding is not supported.

== Screenshots ==

1. **Admin Dashboard View**  
   Display Google Data Studio reports directly within the WordPress admin interface.

2. **Settings Page**  
   Configure your report URL easily through the plugin's intuitive settings page.

3. **Secure and Clean UI**  
   A simple and secure way to manage your marketing data.

== Changelog ==

### 1.1
- Added nonce verification for form submissions.
- Implemented proper input sanitization for settings updates.
- Improved security and compliance with WordPress plugin standards.
- Updated compatibility with WordPress 6.8.

### 1.0
- Initial release of the plugin.

== Upgrade Notice ==

### 1.1
- This update enhances security and input validation. It is recommended for all users to update immediately.

== License ==

This plugin is licensed under the GNU General Public License v2.0. For more details, visit [https://www.gnu.org/licenses/gpl-2.0.html](https://www.gnu.org/licenses/gpl-2.0.html).
