<?php
/**
 * Plugin Name: Marketing Metrics Dashboard
 * Plugin URI: https://redwagon.agency
 * Description: A lightweight plugin to display Google Data Studio reports in the WordPress admin dashboard.
 * Version: 1.0
 * Author: Red Wagon Agency
 * Author URI: https://redwagon.agency
 * License: GPLv2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: marketing-metrics-dashboard
 * Domain Path: /languages
 */

// Add a settings page for Google Data Studio report
add_action('admin_menu', function() {
    add_options_page(
        'Marketing Metrics Dashboard',
        'Marketing Metrics',
        'manage_options',
        'marketing-metrics-dashboard',
        'marketing_metrics_settings_page'
    );
});

// Render the settings page
function marketing_metrics_settings_page() {
    if (isset($_POST['data_studio_url'])) {
        $saved = update_option('data_studio_report_url', esc_url_raw($_POST['data_studio_url']));
        if ($saved) {
            echo '<div class="updated"><p>Settings Saved Successfully.</p></div>';
        } else {
            echo '<div class="error"><p>Failed to Save Settings. Please try again.</p></div>';
        }
    }

    $data_studio_url = get_option('data_studio_report_url', '');
    ?>
    <div class="wrap">
        <h1>Marketing Metrics Dashboard</h1>
        <form method="post">
            <label for="data_studio_url">Google Data Studio Report URL:</label><br>
            <input type="text" name="data_studio_url" id="data_studio_url" value="<?php echo esc_attr($data_studio_url); ?>" style="width: 300px;"><br><br>
            <input type="submit" class="button button-primary" value="Save Settings">
        </form>
        <?php if ($data_studio_url): ?>
            <h2>Preview:</h2>
            <iframe src="<?php echo esc_url($data_studio_url); ?>" width="100%" height="400" frameborder="0" allowfullscreen></iframe>
        <?php endif; ?>
    </div>
    <?php
}

// Add a dashboard widget to display the Google Data Studio report
add_action('wp_dashboard_setup', function() {
    wp_add_dashboard_widget(
        'marketing_metrics_widget',
        'Marketing Metrics Dashboard',
        'marketing_metrics_dashboard_widget'
    );
});

// Render the dashboard widget
function marketing_metrics_dashboard_widget() {
    $data_studio_url = get_option('data_studio_report_url', '');

    if (!$data_studio_url) {
        echo '<p>Please set up your Google Data Studio Report URL in the <a href="options-general.php?page=marketing-metrics-dashboard">settings</a>.</p>';
        return;
    }

    echo '<iframe src="' . esc_url($data_studio_url) . '" width="100%" height="400" frameborder="0" allowfullscreen></iframe>';
}

// Add debug info to check if the URL is being retrieved correctly
add_action('admin_notices', function() {
    $data_studio_url = get_option('data_studio_report_url', '');
    if ($data_studio_url) {
        echo '<div class="notice notice-success"><p>Current Report URL: ' . esc_html($data_studio_url) . '</p></div>';
    } else {
        echo '<div class="notice notice-error"><p>No Google Data Studio URL Found. Please set it in the settings.</p></div>';
    }
});

